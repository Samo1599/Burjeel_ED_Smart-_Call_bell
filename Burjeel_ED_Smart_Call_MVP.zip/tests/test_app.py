from datetime import timedelta
from fastapi.testclient import TestClient
from app import app, SessionLocal, Call, now_utc

client=TestClient(app)

def login(email):
    return client.post('/login',data={'email':email,'password':'Demo123!'},follow_redirects=True)

def reset_calls():
    db=SessionLocal(); db.query(Call).delete(); db.commit(); db.close(); client.get('/logout')

def test_patient_nurse_call_lifecycle():
    reset_calls(); r=client.post('/api/room/room-01-secure-token/call',json={'reason':'Pain'}); assert r.status_code==200; cid=r.json()['call_id']
    login('sara@demo.local'); assert client.post(f'/api/call/{cid}/ack').status_code==200; assert client.post(f'/api/call/{cid}/arrive').status_code==200; assert client.post(f'/api/call/{cid}/resolve').status_code==200
    db=SessionLocal(); assert db.get(Call,cid).status=='resolved'; db.close()

def test_escalation_and_charge_takeover():
    reset_calls(); cid=client.post('/api/room/room-02-secure-token/call',json={'reason':'General assistance'}).json()['call_id']
    db=SessionLocal(); call=db.get(Call,cid); call.created_at=now_utc()-timedelta(seconds=130); db.commit(); db.close()
    login('charge@demo.local'); assert client.get('/charge').status_code==200
    db=SessionLocal(); assert db.get(Call,cid).status=='escalated'; db.close()
    assert client.post(f'/api/call/{cid}/takeover').status_code==200; assert client.post(f'/api/call/{cid}/arrive').status_code==200; assert client.post(f'/api/call/{cid}/resolve').status_code==200

def test_role_access():
    reset_calls(); login('sara@demo.local'); assert client.get('/manager').status_code==403

def test_handover_between_nurses():
    reset_calls(); login('sara@demo.local')
    db=SessionLocal(); from app import Room, User, Handover
    room=db.query(Room).filter_by(code='ED-03').first(); mona=db.query(User).filter_by(email='mona@demo.local').first(); rid=room.id; mid=mona.id; db.query(Handover).delete(); db.commit(); db.close()
    r=client.post('/api/handover',json={'room_id':rid,'to_nurse_id':mid}); assert r.status_code==200; hid=r.json()['handover_id']
    client.get('/logout'); login('mona@demo.local'); assert client.post(f'/api/handover/{hid}/accept').status_code==200
    db=SessionLocal(); room=db.get(Room,rid); assert room.assigned_nurse_id==mid; db.close()
